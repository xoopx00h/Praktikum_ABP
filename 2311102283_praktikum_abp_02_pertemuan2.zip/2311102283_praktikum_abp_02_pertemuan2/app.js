const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const DATA_FILE = './data.json';

// Helper untuk baca/tulis JSON
function readData() {
    return JSON.parse(fs.readFileSync(DATA_FILE));
}
function writeData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

// Halaman Form Input
app.get('/form', (req, res) => res.render('form'));

// Tambah Data (Create)
app.post('/form', (req, res) => {
    const data = readData();
    const newItem = {
        id: Date.now(),
        name: req.body.name,
        email: req.body.email
    };
    data.push(newItem);
    writeData(data);
    res.redirect('/table');
});

// Tabel Data (Read)
app.get('/table', (req, res) => {
    const data = readData();
    res.render('table', { data });
});

// Halaman Edit
app.get('/edit/:id', (req, res) => {
    const data = readData();
    const item = data.find(d => d.id == req.params.id);
    res.render('edit', { item });
});

// Update Data
app.post('/edit/:id', (req, res) => {
    const data = readData();
    const index = data.findIndex(d => d.id == req.params.id);
    if(index !== -1){
        data[index].name = req.body.name;
        data[index].email = req.body.email;
        writeData(data);
    }
    res.redirect('/table');
});

// Delete
app.get('/delete/:id', (req, res) => {
    let data = readData();
    data = data.filter(d => d.id != req.params.id);
    writeData(data);
    res.redirect('/table');
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));